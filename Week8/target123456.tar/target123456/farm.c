/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_150(unsigned x)
{
    return x + 1485241564U;
}

unsigned getval_320()
{
    return 2445773128U;
}

void setval_412(unsigned *p)
{
    *p = 3284633928U;
}

void setval_107(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_450()
{
    return 2425393240U;
}

void setval_394(unsigned *p)
{
    *p = 2462550344U;
}

unsigned addval_351(unsigned x)
{
    return x + 1120113752U;
}

unsigned getval_256()
{
    return 2455259169U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_373()
{
    return 3374371225U;
}

unsigned addval_265(unsigned x)
{
    return x + 3223375497U;
}

unsigned getval_120()
{
    return 3767091248U;
}

void setval_482(unsigned *p)
{
    *p = 3373843081U;
}

void setval_225(unsigned *p)
{
    *p = 851955337U;
}

unsigned addval_475(unsigned x)
{
    return x + 2497743176U;
}

void setval_224(unsigned *p)
{
    *p = 3685011081U;
}

unsigned getval_464()
{
    return 2430634248U;
}

void setval_177(unsigned *p)
{
    *p = 2425668233U;
}

unsigned getval_231()
{
    return 3286272328U;
}

unsigned addval_297(unsigned x)
{
    return x + 516411785U;
}

unsigned addval_401(unsigned x)
{
    return x + 3464577942U;
}

unsigned addval_100(unsigned x)
{
    return x + 3352201542U;
}

void setval_128(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_430()
{
    return 3525366152U;
}

unsigned getval_276()
{
    return 3526414729U;
}

unsigned addval_123(unsigned x)
{
    return x + 3682914697U;
}

unsigned getval_370()
{
    return 3221799561U;
}

unsigned getval_273()
{
    return 3519647831U;
}

unsigned addval_299(unsigned x)
{
    return x + 3281044121U;
}

unsigned addval_452(unsigned x)
{
    return x + 3229929097U;
}

unsigned addval_229(unsigned x)
{
    return x + 3677930121U;
}

unsigned getval_376()
{
    return 3230974601U;
}

unsigned getval_168()
{
    return 2462222821U;
}

unsigned addval_419(unsigned x)
{
    return x + 2496760145U;
}

void setval_115(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_251(unsigned x)
{
    return x + 3224945321U;
}

unsigned addval_409(unsigned x)
{
    return x + 3234123401U;
}

unsigned addval_339(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_498(unsigned x)
{
    return x + 3267613065U;
}

unsigned getval_113()
{
    return 2430634328U;
}

unsigned addval_363(unsigned x)
{
    return x + 3374370473U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
